
#include "passserver.h"
#include "hashtable.h"
using namespace std;
using namespace cop4530;

PassServer::PassServer(size_t size)
{ Hash.sizing(size); }

bool PassServer::load(const char* filename) {return  Hash.load(filename);}

bool PassServer::addUser(std::pair<string, string>&kv)
{
	string a = encrypt(kv.second);
	
	pair<string, string> newuser(kv.first,a);

	return  Hash.insert(newuser);
}

bool PassServer::addUser(std::pair<string, string> && kv) 
{
	pair<string, string> user(std::move(kv));
	bool x= addUser(user);
	
return x;
}



bool PassServer::removeUser(const string & k) {Hash.remove(k);}

bool PassServer::changePassword(const pair<string, string> & p, const string & newpassword) {
	if(p.second == newpassword)
	{
		return false;
	}
	else if(! Hash.contains(p.first)) return false;
	else 
	{
		string password_1 = encrypt(p.second);
		string password_2 = encrypt(password_2);
		
		pair<string, string> spair(p.first, password_1);
		
		if( Hash.match(spair)){
			pair<string, string> spair_1(p.first, password_2);
			 Hash.insert(spair_1); 
			 return true;
		}
		else return false;
	}
																	}

bool PassServer::find(const string & user) const {return  Hash.contains(user);}

void PassServer::dump() const {Hash.dump();}

size_t PassServer::size() const {Hash.tablesize();}

bool PassServer::write_to_file(const char* filename) const {Hash.write_to_file(filename);}

PassServer::~PassServer(){Hash.clear();} 

string PassServer::encrypt(const string & str) {
	char encrypter[] = "$1$########";
	string crypto= crypt(str.c_str(), encrypter);
	crypto.replace(0, 12, "");
	return crypto;
}

