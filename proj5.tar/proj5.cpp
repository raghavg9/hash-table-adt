#include<iostream>
#include<utility>
#include<stdio.h>
#include "passserver.h"
#include "hashtable.h"
using namespace std;

void skip()
{
	char skip;
	while(isspace(cin.peek()) && !cin.eof())
	{
		cin.get(skip);
	}
}

void Menu()
{
  cout << "\n\n";
  cout << "l - Load From File"; 
  cout<< "\n";
  cout << "a - Add User"; 
  cout<< "\n";
  cout << "r - Remove User";
  cout << "\n";
  cout << "c - Change User Password";
  cout<< "\n";
  cout << "f - Find User";
  cout << "\n";
  cout << "d - Dump HashTable"; 
  cout << "\n";
  cout << "s - HashTable Size" ;
  cout<< "\n" ;
  cout << "w - Write to Password File"; 
  cout<< "\n";
  cout << "x - Exit program"; 
  cout<< "\n";
  cout << "\n";
  cout<<" Enter choice:";
  cout<< "\n";
}

int main(){
	cout << "Enter preferred hash table capacity: ";
	int hashcap; cin >> hashcap;
	
	if(hashcap <= 0) 
		{cout <<"**inputut too large for prime_below()\nSet to default capacity\n11\n";
	    hashcap = 11;}

	PassServer pass(hashcap);
    char input;
	do 
	{
		Menu();
		cin >> input;

		if(input == 'l') 
		{
			string file;
			cout <<"Enter password file name to load from: ";
			skip();
			getline(cin, file);
			
			if(!pass.load(file.c_str()))
			{
				cout << "Cannot open file " << file << endl;
			}
		}

		else if(input == 'a') 
		{
			string username, y;
			cout << "Enter user name: ";
			skip();
			getline(cin, username);
			cout << "Enter password: \n";
			skip();
			getline(cin, y);
			pair<string, string> sPair(username, y);
			
			if(pass.addUser(sPair))
			{
				cout << "User " << username << " added.\n";
			}
			else
			{
				cout << "*****Error: User already exists. Could not add user.\n";
			}
		}

		else if(input == 'c') 
		{
			string username, old, neww;
			cout << "Enter username: ";    
			skip();
			getline(cin, username);  
			cout << "Enter password: \n";    
			skip();
			getline(cin, old);
			cout << "Enter new password: "; skip();
			getline(cin, neww);
			
			pair<string, string> oldPair(username, old);
			bool temp=(pass.changePassword(oldPair, neww));
			

			if(temp)
			{cout << "Password changed for user " << username << '\n';}
			else
			{cout << "*****Error: Could not change user password." <<"\n";}
		}

	else if(input == 'r')
                {
                        string username;
                        cout << "Enter username: ";
                        skip();
                        getline(cin, username);
			bool temp=(pass.removeUser(username));
                        

			if(temp)
                        {cout << "User " <<username << " deleted.\n";}
                        else {cout << "*****Error: User not found. Could not delete user.";
                                cout<<"\n";}
                }

		else if(input == 'f') 
		{
			string username;
			cout << "Enter username: "; skip();
			getline(cin, username);
			 bool temp=(pass.find(username));

			
			if(temp){cout << "User " << "'" << username << "'" << " found.\n";}
			else{cout << "User " << "'" << username << "'" << " not found." << endl;}
		}

		else if(input == 'd') {pass.dump();}

		else if(input == 's'){
                       cout << "Size of hashtable: " << pass.size();
			cout << '\n';
		}

		else if(input == 'w')
		{
			string passfilename;
			cout << "Enter password file name to write to: "; skip();
			
			getline(cin, passfilename);
			pass.write_to_file(passfilename.c_str());
		}

		else if(input == 'x') 
		{
		  break;	
		}
		
		else
		{
			cout << "*****Error: Invalid entry.  Try again." << endl;
		}
	}
	while(input != 'x');

	return 0;
}
