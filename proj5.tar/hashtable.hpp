using namespace cop4530;

template<typename K, typename V>
HashTable<K,V>::HashTable(size_t size):theSize(0) 
{
	Listofpair.resize(prime_below(size)); 	
	
}

template<typename K, typename V>
void HashTable<K,V>::sizing(size_t size)
{
	if(tablesize()!= size) 
	{Listofpair.resize(prime_below(size));	 
		theSize = 0;}
}


template<typename K, typename V>  
HashTable<K,V>::~HashTable(){clear();}

template<typename K, typename V>
int HashTable<K,V>::tablesize() const{return theSize;}

template<typename K, typename V>
bool HashTable<K,V>::contains(const K & k) const
{
	for(auto i= Listofpair[myhash(k)].begin(); i!=Listofpair[myhash(k)].end(); ++i)
	{  
		if(i->first == k)
			return true; 
	} return false; 
}

template<typename K, typename V>
size_t HashTable<K,V>::myhash(const K & k) const
{ //return the index of the vector entry where k should be stored.

          hash<K> hashbrowns;
        return hashbrowns(k) % Listofpair.size();
}



template<typename K, typename V>
bool HashTable<K,V>::match(const  pair<K,V> & kv) const
{
auto &key = Listofpair[myhash(kv.first)]; return  find(key.begin(),key.end(),kv)!=key.end();
}

template<typename K, typename V> 
bool HashTable<K,V>::insert(const  pair<K,V> & kv)  
{
	if(match(kv)) {return false;} //key already exists and cannot be added
	else if(contains(kv.first)) //for updating keyvalue if key exists
	{
		auto &key = Listofpair[myhash(kv.first)];
		for(auto i=key.begin(); i !=key.end(); ++i) 
		{
				if(i->first == kv.first) {auto switcheroo= key.erase(i);key.insert(switcheroo, kv); }
		}return true;
	}
	else 
	{Listofpair[myhash(kv.first)].push_back(kv); 
			if(++theSize > Listofpair.size()){rehash(); }
			return true;
	}	
}

template<typename K, typename V>
bool HashTable<K,V>::insert( pair<K,V> && kv) 
{const  pair<K,V> keystone =  move(kv);	return insert(keystone);  }


template<typename K, typename V>
bool HashTable<K,V>::remove(const K&k)  
{
	auto &itr=Listofpair[myhash(k)];	
	bool check=0;
	auto i=itr.begin(); 

	while(i !=itr.end())
	{  
			if(i->first == k) 
			{
				i = itr.erase(i);	
				theSize--; 
				 check= 1;
			}

			i++;
	} 

	return check;
}

template<typename K, typename V> 
void HashTable<K,V>::makeEmpty() { Listofpair.clear(); theSize = 0;}


template<typename K, typename V>
bool HashTable<K,V>::load(const char* filename) 
{
	char k;
	 pair<K,V> keyval;
	 ifstream fin;  
	
	 fin.open(filename);   
	if(!fin)
	{cout << filename << " is invalid!\n" ; return false;}
	
	while(fin)  
	{
			 getline( fin, keyval.first, ' ');  
			while(isspace(fin.peek()))   
				fin.get(k);  
			getline( fin, keyval.second,'\n');
			while(isspace( fin.peek()))  
			 fin.get(k); 
			
			insert(keyval);

	}
	 fin.close();	return true;
}

template<typename K, typename V>
void HashTable<K,V>::dump() const
{
	for(int j = 0; j < Listofpair.size(); j++) 
	{ 
		cout << "v[" ;
		cout<< j;
		cout << "]:";

    if(!Listofpair[j].empty())
    { 
		auto i = Listofpair[j].begin(); 
	while(i != Listofpair[j].end()) 
		{
			if(i != Listofpair[j].begin())
				cout << ':'; 

			cout << i->first; 
			cout<< ' ' ;
			cout<< i->second;
			i++;
		}
		cout << endl;
	}
	}
}

template<typename K, typename V>
bool HashTable<K,V>::write_to_file(const char* filename) const
{ 
	 ofstream fout;   
	fout.open(filename);
	//ptinting out each pair values into file with the help of nested loop
	if(!fout) return false; //bad file

	for(int j=0; j<Listofpair.size();j++){
		auto i = Listofpair[j].begin();
		while(i!=Listofpair[j].end()){
			fout << i->first; 
			fout << ' '; 
			fout<< i->second ;
			fout<<endl; 
			i++;
		}
	}
	fout.close(); 
	return true;  
}

template<typename K, typename V>
void HashTable<K,V>::clear()
{
	makeEmpty();  
}

template<typename K, typename V>
void HashTable<K,V>::rehash() //hashing to twice the size of the hashtables current size by calling resize function 
{
	auto  placeholder=Listofpair;
	Listofpair.resize(prime_below(2 * Listofpair.size()));

	for(auto & elements: Listofpair) 	elements.clear();	
	theSize = 0;
	
	for(auto & elements:  placeholder)
	{
		for(auto & Pair:elements) insert(move(Pair));
	}
}
//given by professor
template<typename K, typename V>
unsigned long HashTable<K,V>::prime_below(unsigned long n)
{
	  if(n > max_prime)
    {
       cerr << "input too large for prime_below()\n";
      return 0;
    }
	  if(n == max_prime)
    {
      return max_prime;
    }
	  if(n <= 1)
    {
       cerr << "input too small \n";
      return 0;
    }
   vector <unsigned long> v(n+1);
  setPrimes(v);
  while(n > 2)
    {
      if(v[n] == 1)
        return n;
      --n;
    }

  return 2;
}
 


 //given by professor
template <typename K, typename V>
void HashTable<K,V>::setPrimes( vector<unsigned long>& vprimes)
{
  int i = 0;
  int j = 0;

  vprimes[0] = 0;
  vprimes[1] = 0;
  int n = vprimes.capacity();

  for(i = 2; i < n; ++i)
    vprimes[i] = 1;

  for(i = 2; i*i < n; ++i)
    {
      if(vprimes[i] == 1)
        for(j = i + i ; j < n; j += i)
          vprimes[j] = 0;
    }
}
